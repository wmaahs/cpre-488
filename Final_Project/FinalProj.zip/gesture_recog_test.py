import cv2
import mediapipe as mp
import numpy as np
import time
import serial
import sys

#Pitch
#This is done with a curve fit https://mycurvefit.com/
#min point: 1.5, 0
#mid point: 3, 0.5
#max point: 8, 1
#using exponential fit
#y = OFFSET - MULTIPLER/2^(x/EXP_DIVISOR)
PITCH_OFFSET = 1.069784     
PITCH_MULTIPLIER = 2.008547
PITCH_EXP_DIVISOR = 1.65047

PITCH_MIN = 1.5 #must be same as minimum fit above or else bad things
PITCH_MAX = 8 #must be same as maximum fit above or else bad things
PITCH_SCALE = 255 #255 for byte packet size

#Roll
#This is done with a curve fit https://mycurvefit.com/
#min point: 0.6, 0
#mid point: 1.3, 0.5
#max point: 3, 1
#using exponential fit
#y = OFFSET - MULTIPLER/2^(x/EXP_DIVISOR)
ROLL_OFFSET = 1.176395   
ROLL_MULTIPLIER = 1.89047
ROLL_EXP_DIVISOR = 0.8767156

ROLL_MIN = 0.6 #must be same as minimum fit above or else bad things
ROLL_MAX = 3 #must be same as maximum fit above or else bad things
ROLL_SCALE = 255 #255 for byte packet size

#Thrust
THRUST_MIN = 100 #minimum size, can be calibrated
THRUST_MAX = 160 #maximum size, can be calibrated
THRUST_SCALE = 255 #255 for byte packet size

#Yaw
YAW_SCALE = 255


cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 360)

serialChannel = sys.argv[1]#get the serial channel
if serialChannel != "NONE":
    ser = serial.Serial(serialChannel, 115200, timeout=0.05)

mpHands = mp.solutions.hands
hands = mpHands.Hands(static_image_mode=False,
                      model_complexity=1,
                      max_num_hands=1,
                      min_detection_confidence=0.5,
                      min_tracking_confidence=0.5)
mpDraw = mp.solutions.drawing_utils



def build_and_send_packet(thrust, yaw, pitch, roll):
    thrust = int(thrust)
    yaw = int(yaw)
    pitch = int(pitch)
    roll = int(roll)
    
    checksum = (66+80+thrust+yaw+pitch+roll)%256
    packet = bytearray([66, 80, thrust, yaw, pitch, roll, checksum])
    ser.write(packet)

pFPS = 0
pTime = 0
cTime = 0
point1_index=4
point2_index=8
distances ={}
key = 0

analog_roll = ROLL_SCALE / 2
analog_pitch = PITCH_SCALE / 2
analog_thrust = 0
analog_yaw = YAW_SCALE / 2

def calculate_angle(p1,p2,p3):
        p1=np.array(p1)
        p2=np.array(p2)
        p3=np.array(p3)

        v1=p1-p2
        v2=p3-p2
        dot=np.dot(v1,v2)
        mag1=np.linalg.norm(v1)
        mag2=np.linalg.norm(v2)

        rad=np.arccos(dot / (mag1*mag2))
        degree=np.degrees(rad)
        return degree
        
def constrain(n,min,max):
    if n > max:
        return max
    if n < min:
        return min
    return n
    
while key != 27:
    success, img = cap.read()
    img = cv2.flip(img, 1)
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = hands.process(imgRGB)
    #print(results.multi_hand_landmarks)
    
    cv2.circle(img,(840,350),2,(255,0,0), cv2.FILLED)
    
    if results.multi_hand_landmarks:
        for handLms in results.multi_hand_landmarks:
        
            lmList = []
            for id, lm in enumerate(handLms.landmark):
                # print(id,lm)
                h, w, c = img.shape
                cx, cy = int(lm.x *w), int(lm.y*h)
                
                lmList.append([id,cx,cy])
                text = str(id)
                cv2.circle(img, (cx,cy), 3, (255,0,255), cv2.FILLED)
                cv2.putText(img,text,(cx,cy),cv2.FONT_HERSHEY_SIMPLEX,.5,(255,255,255),1)
            
            
            #enumerate distances between landmarks
            for i in range(len(lmList)):
                distances.setdefault(lmList[i][0],{})
                for j in range(i+1,len(lmList)):  
                    distances.setdefault(lmList[j][0],{})
                    x1, y1 = lmList[i][1], lmList[i][2]
                    x2, y2 = lmList[j][1], lmList[j][2]
                    distance = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
                    distances[lmList[i][0]][lmList[j][0]] = distance
                    #distances[lmList[j][0]][lmList[i][0]] = distance

            
            ############################################# ROLL #############################################
            rollRatio = distances[5][9]/distances[13][17]
            #print(rollRatio)
            
            if(rollRatio < ROLL_MIN):
                analog_roll = 0
                
            elif(rollRatio < ROLL_MAX):
                analog_roll = int((ROLL_OFFSET - (ROLL_MULTIPLIER/(2**(rollRatio/ROLL_EXP_DIVISOR))))*ROLL_SCALE)
            
            else:
                analog_roll = PITCH_SCALE
                
            text = "Roll "+str(analog_roll)
            cv2.putText(img,text, (10,160), cv2.FONT_HERSHEY_PLAIN, 3, (0,127,255), 3)

            ############################################# PITCH #############################################
            pitchRatio = distances[0][9]/distances[10][11]
            #print(pitchRatio)
            if(pitchRatio < PITCH_MIN):
                analog_pitch = 0
                
            elif(pitchRatio < PITCH_MAX):
                analog_pitch = int((PITCH_OFFSET - (PITCH_MULTIPLIER/(2**(pitchRatio/PITCH_EXP_DIVISOR))))*PITCH_SCALE)
            
            else:
                analog_pitch = PITCH_SCALE
                
            text = "Pitch "+str(analog_pitch)
            cv2.putText(img,text, (10,120), cv2.FONT_HERSHEY_PLAIN, 3, (0,0,255), 3)
            
            ############################################# THRUST #############################################
            #print(distances[0][9])
            currentThrustInput = distances[0][9]
            
            if(currentThrustInput < THRUST_MIN):
                analog_thrust = 0
            elif(currentThrustInput < THRUST_MAX):
                analog_thrust = int(THRUST_SCALE*(currentThrustInput-THRUST_MIN)/(THRUST_MAX-THRUST_MIN))          
            else:
                analog_thrust = THRUST_SCALE
            
            #text = "ThrustPre "+str(analog_thrust)
            #cv2.putText(img,text, (10,200), cv2.FONT_HERSHEY_PLAIN, 3, (255,0,255), 3)
            
            #hacky thrust adjustment based on pitch
            if analog_pitch > 127:
                analog_thrust = int(analog_thrust + (127 - analog_pitch)*0.1)
            else:
                analog_thrust = int(analog_thrust + (127 - analog_pitch)*1)
            analog_thrust = constrain(analog_thrust,0,THRUST_SCALE)
            
            text = "Thrust "+str(analog_thrust)
            cv2.putText(img,text, (10,80), cv2.FONT_HERSHEY_PLAIN, 3, (255,0,255), 3)
           
            ############################################# YAW #############################################
            yawScale =(lmList[12][2]-lmList[0][2])*(distances[0][12])
            #print(yawScale)
            
            if(yawScale > 30000):
                cv2.putText(img,'Yaw Right', (10,240), cv2.FONT_HERSHEY_PLAIN, 3, (255,0,255), 3)
                analog_yaw = YAW_SCALE*3/4
            elif(yawScale < -24000):
                cv2.putText(img,'Yaw Left', (10,240), cv2.FONT_HERSHEY_PLAIN, 3, (255,0,255), 3)
                analog_yaw = YAW_SCALE*1/4
            else:
                cv2.putText(img,'Yaw Neutral', (10,240), cv2.FONT_HERSHEY_PLAIN, 3, (255,0,255), 3)
                analog_yaw = YAW_SCALE/2
                
                
            #mpDraw.draw_landmarks(img, handLms, mpHands.HAND_CONNECTIONS)
    else:
        analog_thrust = 0

    cTime = time.time()
    fps = 1/(cTime-pTime)
    pTime = cTime
    print("FPS: "+str((fps+pFPS)/2))
    pFPS = fps
    #cv2.putText(img,str(int(fps)), (10,200), cv2.FONT_HERSHEY_PLAIN, 3, (255,0,255), 3)
    
    if serialChannel != "NONE":
        build_and_send_packet(analog_thrust, analog_yaw, analog_pitch, analog_roll)
        line = ser.readline()
        print(str(line))
    
    img_full = cv2.resize(img, (860, 540)) 
    cv2.imshow("Image", img_full)
    key = cv2.waitKey(1)
    
