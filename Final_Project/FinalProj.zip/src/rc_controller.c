#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include <xparameters.h>
#include "xuartps_hw.h"

#define PPM_CONFIG   (*(volatile u32 *)(XPAR_AXI_PPM_V1_0_0_BASEADDR+0x00))
#define PPM_R_NUM_CAP   (*(volatile u32 *)(XPAR_AXI_PPM_V1_0_0_BASEADDR+0x04))
#define PPM_R_LOCK_TIME (*(volatile u32 *)(XPAR_AXI_PPM_V1_0_0_BASEADDR+0x08))
#define PPM_R_CHNL_21 (*(volatile u32 *)(XPAR_AXI_PPM_V1_0_0_BASEADDR+0x0C))
#define PPM_R_CHNL_43 (*(volatile u32 *)(XPAR_AXI_PPM_V1_0_0_BASEADDR+0x10))
#define PPM_R_CHNL_65 (*(volatile u32 *)(XPAR_AXI_PPM_V1_0_0_BASEADDR+0x14))
#define PPM_W_GAP_TIME (*(volatile unsigned int *)(0x43C00000+0x0020))
#define PPM_W_IDLE_TIME (*(volatile unsigned int *)(0x43C00000+0x0024))
#define PPMREG_OUT_21 (*(volatile unsigned int *)(0x43C00000+0x0028))
#define PPMREG_OUT_43 (*(volatile unsigned int *)(0x43C00000+0x002c))
#define PPMREG_OUT_65 (*(volatile unsigned int *)(0x43C00000+0x0030))

#define GPIO_1_BTNS (*(volatile unsigned int *)(0x41200000+0x0000))
#define GPIO_2_SW (*(volatile unsigned int *)(0x41210000+0x0000))

#define GPIO_1_TRI (*(volatile unsigned int *)(0x41200000+0x0004))
#define GPIO_2_TRI (*(volatile unsigned int *)(0x41210000+0x0004))


#define NUM_CHANNELS 6
#define BUFFERSIZE 16
//predefined cycle time to calculate idle pulse
#define CYCLETIME 2000000
#define GAPTIME 0x9C40
#define THRUST_OFFSET_VALUE 0x0F00
#define THRUST_MAX_VALUE 0x2600
#define THRUST_SCALE (THRUST_MAX_VALUE - THRUST_OFFSET_VALUE)
#define YAW_OFFSET_VALUE 0x1500
#define YAW_MAX_VALUE 0x2000
#define YAW_SCALE (YAW_MAX_VALUE - YAW_OFFSET_VALUE)
#define PITCH_OFFSET_VALUE 0x1500
#define PITCH_MAX_VALUE 0x2000
#define PITCH_SCALE (PITCH_MAX_VALUE - PITCH_OFFSET_VALUE)
#define ROLL_OFFSET_VALUE 0x1500
#define ROLL_MAX_VALUE 0x2000
#define ROLL_SCALE (ROLL_MAX_VALUE - ROLL_OFFSET_VALUE)

//circular buffer
u8 inputSerialBuffer[BUFFERSIZE];
int readLocation;
int writeLocation;
int bytesInBuffer;

int checksum;


int prev_num_cap;
int i = 0;
u16 channel1, channel2, channel3, channel4, channel5, channel6;
u16 rollVal, pitchVal, yawVal, thrustVal;


//increment function for read and write locations, will wrap if at end
void incrementReadLocation(){
	readLocation++;
	bytesInBuffer--;
	if (readLocation >= BUFFERSIZE){
		readLocation = 0;
	}

}

void incrementWriteLocation(){
	writeLocation++;
	bytesInBuffer++;
	if (writeLocation >= BUFFERSIZE){
		writeLocation = 0;
	}
}

int main()
{
	readLocation = 0;
	writeLocation = 0;
	bytesInBuffer = 0;
    init_platform();

    //initialize reg 0 to software relay, initialize lock time, initialize gaptime to defined above
    PPM_CONFIG = 0x00000001;
    PPM_R_LOCK_TIME = 400000;
    prev_num_cap = 0;
    PPM_W_GAP_TIME = GAPTIME;


    //init buttons and switiches
	GPIO_1_TRI |= 0b11111;
	GPIO_2_TRI |= 0b11111111;



	//    for(i=0;i<4*16;i+=4){
//   xil_printf("%d : %x\r\n",i,(*(volatile u32 *)(XPAR_AXI_PPM_V1_0_0_BASEADDR+i)));
//    }

    while(1){

    	//while(PPM_R_NUM_CAP == prev_num_cap){}//hold till next cycle
    	prev_num_cap = PPM_R_NUM_CAP;

    	if ((GPIO_2_SW &0b00000001) == (0b00000001)){
    		PPM_CONFIG = 0x00000001; //if switch 0 is on, sw relay
    	}
    	else{
    		PPM_CONFIG = 0x00000000; //else hardware relay
    	}

    	if ((GPIO_1_BTNS  &0b00000001) == 0b00000001){
    		cleanup_platform(); //center button kills program
    		return 0;
    	}

    	/*if there is data, write to buffer if buffer has room*/
    	while ((XUartPs_IsReceiveData(STDIN_BASEADDRESS) && bytesInBuffer < BUFFERSIZE)) {
    		inputSerialBuffer[writeLocation] = inbyte();
    		incrementWriteLocation();
    	}


    	/*
    	 * Check if the Begin Packet characters are there, then the next 4 written values will be thrust
    	 * ywa, pitch, roll
    	 */
    	if (bytesInBuffer >= 7){
    		if(inputSerialBuffer[readLocation] == 'B'){
    			incrementReadLocation();
        		if(inputSerialBuffer[readLocation] == 'P'){
        			incrementReadLocation();
        			xil_printf("\nFound Packet: ");

        			checksum = 'B'+'P';

        			xil_printf("Thrust %3d ",inputSerialBuffer[readLocation]);
        			checksum += inputSerialBuffer[readLocation];
        			thrustVal = ((inputSerialBuffer[readLocation] * THRUST_SCALE) / 255) + THRUST_OFFSET_VALUE;
        			incrementReadLocation();

        			xil_printf("Yaw %3d ",inputSerialBuffer[readLocation]);
        			checksum += inputSerialBuffer[readLocation];
        			yawVal = (((inputSerialBuffer[readLocation]) * YAW_SCALE) / 255) + YAW_OFFSET_VALUE;
        			incrementReadLocation();

        			xil_printf("Pitch %3d ",inputSerialBuffer[readLocation]);
        			checksum += inputSerialBuffer[readLocation];
        			pitchVal = (((inputSerialBuffer[readLocation]) * PITCH_SCALE) / 255) + PITCH_OFFSET_VALUE;
        			incrementReadLocation();

        			xil_printf("Roll %3d ",inputSerialBuffer[readLocation]);
        			checksum += inputSerialBuffer[readLocation];
        			rollVal = (((inputSerialBuffer[readLocation]) * ROLL_SCALE) / 255) + ROLL_OFFSET_VALUE;
        			incrementReadLocation();

        			if(checksum % 256 == inputSerialBuffer[readLocation]){
        				//if not in play mode, output as normal
						//capture clk cycles for each channel
						//channel1 = PPM_R_CHNL_21 & 0xFFFF;
						//channel2 = (PPM_R_CHNL_21>>16) & 0xFFFF;
						channel3 = PPM_R_CHNL_43 & 0xFFFF;
						//channel4 = (PPM_R_CHNL_43>>16) & 0xFFFF;
						channel5 = PPM_R_CHNL_65 & 0xFFFF;
						channel6 = (PPM_R_CHNL_65>>16) & 0xFFFF;

						channel4 = yawVal;
						channel2 = pitchVal;
						channel1 = rollVal;
						channel3 = (channel3 < thrustVal) ? channel3 : thrustVal;
						//pass values above to output registers
						PPMREG_OUT_21 = ((channel2 << 16) | channel1);
						PPMREG_OUT_43 = ((channel4 << 16) | channel3);
						PPMREG_OUT_65 = ((channel6 << 16) | channel5);
						PPM_W_IDLE_TIME = CYCLETIME - GAPTIME * 7 - ((channel1+channel2+channel3+channel4+channel5+channel6) << 4);

        			}else{
        				xil_printf("Checksum FAILURE");
        			}
        			incrementReadLocation();
        		}
        		else{incrementReadLocation();}
    		}
    		else{incrementReadLocation();}
    	}





    	if ((GPIO_2_SW & 0b00000010) == 0b00000010){//switch one turns on software debug mode -->putty terminal
    		xil_printf("\t\tNC: %7d,C1: %7d,C2: %7d,C3: %7d,C4: %7d,C5: %7d,C6: %7d",prev_num_cap,channel1,channel2,channel3,channel4,channel5,channel6);
    	}



    }



    cleanup_platform();
    return 0;
}



